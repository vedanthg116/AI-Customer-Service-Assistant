from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import os
from database import engine, Base
from api.routers import chat_router, websocket_router

# Create FastAPI app
app = FastAPI(
    title="Customer Support API",
    description="AI-powered customer support system with multilingual support",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(chat_router.router, prefix="/api", tags=["chat"])
app.include_router(websocket_router.router, tags=["websocket"])

# Root endpoint
@app.get("/")
async def root():
    return {
        "message": "Customer Support API is running!",
        "status": "success",
        "version": "1.0.0",
        "features": [
            "Multilingual Support",
            "AI-powered Analysis",
            "WebSocket Real-time Communication",
            "Azure SQL Database",
            "Image Analysis with OCR"
        ]
    }

# Health check endpoint
@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "database": "connected",
        "ai_service": "available",
        "websocket": "ready"
    }

# Create database tables
@app.on_event("startup")
async def startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✅ Database tables created successfully!")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000) 